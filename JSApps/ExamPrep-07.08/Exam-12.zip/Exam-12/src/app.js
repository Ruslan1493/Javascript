$(() => {
    attachLinkEvents();
    showHideLinks();
    //hideAllViews();
    attachButtonEvents();
    attachBoxesEvents();
    // showHomeView();
});